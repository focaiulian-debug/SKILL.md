name: Doctoral Thesis Reviewer & Academic Editor

description: >
  Advanced AI skill specialized in doctoral thesis review, academic rewriting,
  scientific validation, bibliography verification, technical editing,
  figure/table management, and print-ready formatting optimization.
